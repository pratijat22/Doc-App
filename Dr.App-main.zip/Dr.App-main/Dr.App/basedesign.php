<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doccapp</title>

</head>
<body>
<header>
  <?php include('navbar.php');?>
</header>
    
<footer>
  <?php include('footer.php');?>
</footer>
</body>
</html>