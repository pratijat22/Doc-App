<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>exmp4</title>
         <link rel="stylesheet" href="styles.css">

    <style>
.contact-name{
	color: #313131;
	font-size: 18px;
	margin:;
}
.contact-detail{
	color: white;
	line-height:;
	font-size: 15px;
}        
.contacts{
	text-align: center;
}
.contact{
    width: 180px;
    height: 80px;
	padding: 50px;
	transition: all .4s ease-in-out;
    background-color: #ACC6FF;
    opacity: 0.9;
}
        .cts{
            padding-left:17%;
        }
        .ctd{
            padding-left: 10px;
            padding-right: 10px;

        }
    </style>
</head>
<body>
    <table class="cts">
         <tr>
            <th class="ctd">
				<div class="contact contacts">
						<div class="contact-name">
							Address :
						</div>
						<div class="contact-detail">
							Susila Devi Bansal College<br>
                           Indore (M.P.)						 
						</div>
				</div> <!-- /.contact --></th>
             <th class="ctd">
				<div class="contact">
						<div class="contact-name">
							Phone :
						</div>
						<div class="contact-detail">
							Local: 0731-123456 <br>
							Mobile: +91-1234567890
						</div>
				</div> <!-- /.contact --></th>
             <th class="ctd">
				<div class="contact">
						<div class="contact-name">
							 Our Email Address :
						</div>
						<div class="contact-detail">
							
							   sdb@gmail.com<br>
							   info.sdb@gmail.com

						</div>
				</div> <!-- /.contact --></th>
              </tr>
    </table>
</body>
</html>