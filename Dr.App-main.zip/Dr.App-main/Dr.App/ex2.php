<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    
    <style>
        .abc{
            text-align:center;
            border: 5px solid green;
        }
        
        body{
        background-image: url(c_background.jpg);
            width: 100%;
            height: 100%;
  background-repeat: no-repeat;
  background-attachment: fixed;

        }
    </style>
</head>
<body>
    <div class="xyz">
    <div class="abc">
        
            <h2>Ajay</h2>    
        
    </div></div>
    
</body>
</html>