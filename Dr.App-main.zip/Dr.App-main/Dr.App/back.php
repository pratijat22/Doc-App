<script>
function goBack() {
  window.history.back()
}
</script>
  <div id="back_button">    
    <button onclick="goBack()" >&lt;&nbsp;Back</button>
  </div>